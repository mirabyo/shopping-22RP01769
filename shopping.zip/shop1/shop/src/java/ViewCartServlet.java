import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ViewCartServlet")
public class ViewCartServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookies = request.getCookies();
        String cart = "";
        
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("cart")) {
                    cart = URLDecoder.decode(cookie.getValue(), "UTF-8");
                    break;
                }
            }
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>Your Cart</h2>");
        
        if (!cart.isEmpty()) {
            out.println("<ul>");
            String[] items = cart.split(",");
            for (String item : items) {
                out.println("<li>" + item + "</li>");
            }
            out.println("</ul>");
        } else {
            out.println("<p>Your cart is empty.</p>");
        }
          out.println(" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button><a href=\"index.jsp\" style='text-decoration: none;col'>Back Shopping Cart</a></button>");
           out.println(" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button><a href=\"remove.html\" style='text-decoration: none;'>Remove Cart</a></button>");
           out.println(" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button><a href=\"clear.html\" style='text-decoration: none;'>Clear Cart</a></button>");
           
           
          
        out.println("</body></html>");
    }
}
