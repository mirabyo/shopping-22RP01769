import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ClearCartServlet")
public class ClearCartServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Clear the cart cookie
        Cookie cartCookie = new Cookie("cart", "");
        cartCookie.setMaxAge(0); // Delete the cookie
        response.addCookie(cartCookie);
        
        response.sendRedirect("ViewCartServlet");
    }
}
